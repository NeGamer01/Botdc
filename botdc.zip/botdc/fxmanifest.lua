fx_version "bodacious"
games {"gta5"}

server_script "bot.js"